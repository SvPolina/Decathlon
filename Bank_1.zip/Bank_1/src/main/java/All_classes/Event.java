package All_classes;

public enum Event {

		M_100("25.4347","18","1.81"),
		Long_jump("0.14354","220","1.4"),
		Shot_put("51.39","1.5","1.05"),
		High_jump("0.8465","75","1.42"),
		M_400("1.53775","82","1.81"),
		M_110("5.74352","28.5","1.92"),
		Discuc_throw("12.91","4","1.1"),
		Pole_vault("0.2797","100","1.35"),
		Javelin_throw("10.14","7","1.08"),
		M_150("0.03768","480","1.85");
	
	private final String A;
	private final String B;
	private final String C;
	
    Event(String A, String B, String C)
    {
    	this.A=A;
    	this.B=B;
    	this.C=C;
    }
    
    public String getA()
    {return A;}
	
    public String getB()
    {return B;}
    
    public String getC()
    {return C;}

}
