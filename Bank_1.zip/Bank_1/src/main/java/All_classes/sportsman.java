package All_classes;

import java.util.ArrayList;



public class sportsman {
	
	private String name;
	private String achievements;
	private ArrayList<Double> achievements_D;
	private String score;
	private String place;
	
	public sportsman(String name,String achievements,ArrayList<Double> achievements_D,String score,String place )
	{
		this.name=name;
		this.achievements=achievements;
		this.achievements_D=achievements_D;
		this.score=score;
		this.place=place;
	}
	
	public String getName()
	{return name;}
	
	public String getAchievements()
	{return achievements;}
	
	public ArrayList<Double> getAchievements_D()
	{return achievements_D;}
  
	public String getScore()
	{return score;}
	
	public String getPlace()
	{return place;}
	
	@Override
	public boolean equals(Object sportsman1)
	{   
		sportsman sportsman2=(sportsman)sportsman1;
		if(sportsman2.getScore()==this.getScore())
		{
			return true;
		}
		else
		{
			return false;
		}	
	}
	
	
	
	@Override
	public String toString()
	{
		return String.format("%s, %s, %s, %s", name, achievements, score, place);
	}
	
	
	
}
