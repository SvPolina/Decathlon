package All_classes;

import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;
import org.w3c.dom.*;

public class Output_XML 
{   
	private final ArrayList<sportsman> Athletes;
	private String out_name;
	
	public Output_XML (ArrayList<sportsman> Athletes,String out_name)
	{
		this.Athletes=Athletes;
		this.out_name=out_name;
		
	}
	
	public  void doc_build()
	{
		try {
	         DocumentBuilderFactory dbFactory =	DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         Document doc = dBuilder.newDocument();
	         
	         // root element
	         Element rootElement = doc.createElement("Athletes");
	         doc.appendChild(rootElement);
	      
	         
	for (sportsman ath:Athletes)
	{
	         // Athlets element
	         Element athlete = doc.createElement("Athlete");
	         rootElement.appendChild(athlete);	         
	    
	         Element sportsman_0 = doc.createElement("Name");	      
	         sportsman_0.appendChild(doc.createTextNode(ath.getName()));
	         athlete.appendChild(sportsman_0);
	        	 
	        	 Element sportsman_a = doc.createElement("A");	   	   
	        	 sportsman_a.appendChild(doc.createTextNode(Double.toString(ath.getAchievements_D().get(0))));
	   	         athlete.appendChild(sportsman_a );
	   	         
	   	         Element sportsman_b = doc.createElement("B");	   	   
	        	 sportsman_b.appendChild(doc.createTextNode(Double.toString(ath.getAchievements_D().get(1))));
	   	         athlete.appendChild(sportsman_b );
	   	         
	   	         Element sportsman_c = doc.createElement("C");	   	   
	        	 sportsman_c.appendChild(doc.createTextNode(Double.toString(ath.getAchievements_D().get(2))));
	        	 athlete.appendChild(sportsman_c );	   	         	   	         
	   	         
	   	         Element sportsman_d = doc.createElement("D");	   	   
	        	 sportsman_d.appendChild(doc.createTextNode(Double.toString(ath.getAchievements_D().get(3))));
	   	         athlete.appendChild(sportsman_d );
	   	         
	   	         Element sportsman_e = doc.createElement("E");	   	   
	        	 sportsman_e.appendChild(doc.createTextNode(Double.toString(ath.getAchievements_D().get(4))));
	   	         athlete.appendChild(sportsman_e );
	   	         
	   	         Element sportsman_f = doc.createElement("F");	   	   
	        	 sportsman_f.appendChild(doc.createTextNode(Double.toString(ath.getAchievements_D().get(5))));
	   	         athlete.appendChild(sportsman_f );
	   	         
	   	         Element sportsman_g = doc.createElement("G");	   	   
	        	 sportsman_g.appendChild(doc.createTextNode(Double.toString(ath.getAchievements_D().get(6))));
	        	 athlete.appendChild(sportsman_g );	   	         	   	         
	   	         
	   	         Element sportsman_h = doc.createElement("H");	   	   
	        	 sportsman_h.appendChild(doc.createTextNode(Double.toString(ath.getAchievements_D().get(7))));
	   	         athlete.appendChild(sportsman_h );
	   	         
	   	         Element sportsman_i = doc.createElement("I");	   	   
	        	 sportsman_i.appendChild(doc.createTextNode(Double.toString(ath.getAchievements_D().get(8))));
	   	         athlete.appendChild(sportsman_i );
	   	         
	   	         Element sportsman_j = doc.createElement("J");	   	   
	        	 sportsman_j.appendChild(doc.createTextNode(Double.toString(ath.getAchievements_D().get(9))));
	   	         athlete.appendChild(sportsman_j );
	        
	         

	         Element sportsman1 = doc.createElement("Place");	  
	         sportsman1.appendChild(doc.createTextNode(ath.getPlace()));
	         athlete.appendChild(sportsman1);
	         
	         Element sportsman2 = doc.createElement("Score");	
	         sportsman2.appendChild(doc.createTextNode(ath.getScore()));
	         athlete.appendChild(sportsman2);	         	         

	         // write the content into xml file
	         TransformerFactory transformerFactory = TransformerFactory.newInstance();
	         Transformer transformer = transformerFactory.newTransformer();
	         DOMSource source = new DOMSource(doc);
	         StreamResult result = new StreamResult(new File(out_name)); 
	         transformer.transform(source, result);	     
	    
	}      
	      } catch (Exception e) { e.printStackTrace(); }
	   }

	}


