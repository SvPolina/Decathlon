package All_classes;

import java.io.IOException;
import java.lang.IllegalStateException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Scanner;

import javax.imageio.IIOException;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class testBank {
	
	public  static 	Scanner input;	
	private static 	ArrayList<String> records=new ArrayList<String>();
	private static 	processRecords prc;
	private static  String Input_name;
	private static  String Input_format;
	private static  String Output_name;
	private static  String Output_format;
	
	public static void main(String[] args ) throws IOException 
	{	
		
		askInput();			
		switch(Input_format)		
		{ 		
		  case "txt":
	    		openFile();
	    		readRecords();
	    		break;		
		 }	
		
		switch(Output_format)		
		{ 
		  case "xml":
			  prc = new processRecords(records,Output_name+"."+Output_format);
			  break;
		}		
		prc.perform();
		XML_HTML html=new XML_HTML(Output_name);
		closeFile();		
	}
	
//Opens file
	public static void openFile () throws IOException
	{
		try
		{
			input=new Scanner(Paths.get(Input_name+"."+Input_format)); 
		}
		catch( IOException ioException)
		{
			System.err.println("Error openning file.Terminating");
			System.exit(1);
		}		
	}
	
//Reads input records into ArrayList
	public static void readRecords()
	{
		try
		{
			while(input.hasNext())
			{   
				String name=input.next();			
				String det=input.next();				
				String record=name+" "+det;				
				records.add(record);				
			}
		}
		catch(NoSuchElementException elementException)
		{
			System.err.println("File improperly formed.Terminating");
		}
		catch(IllegalStateException stateException)
		{
			System.err.println("Error reading from file.Terminating");
		}		
	}	
	
//Closes input file	
	public static void closeFile()
	{
		if (input!=null)
		{
			input.close();
		}
	}

//Opens a dialog window to ask for the input & output file names	
	private static void askInput()
	{
		JTextField inputFile = new JTextField(10);
		JTextField inputFormat = new JTextField(10);
	    JTextField outputFile = new JTextField(10);
	    JTextField outputFormat = new JTextField(10);
	    JPanel myPanel = new JPanel();
	    myPanel.setLayout(new BoxLayout( myPanel, BoxLayout.Y_AXIS)); 	   
	    myPanel.add(new JLabel("Please provide input file name: (Decathlon)"));
	    myPanel.add(inputFile);
	    myPanel.add(new JLabel("Please provide input format: (txt)"));
	    myPanel.add(inputFormat);
	    
	    myPanel.add(Box.createHorizontalStrut(25)); 
	    myPanel.add(new JLabel("Please provide output file name:"));
	    myPanel.add(outputFile);	
	    myPanel.add(new JLabel("Please provide output format: (xml)"));
	    myPanel.add(outputFormat);
	    
	    int result = JOptionPane.showConfirmDialog(null, myPanel,"Input and output file names", JOptionPane.OK_CANCEL_OPTION);
	    if (result == JOptionPane.OK_OPTION) 
	    {   
	     Input_name 	= inputFile.getText();
	     Input_format 	= inputFormat.getText();
	     Output_name	= outputFile.getText();
	     Output_format	= outputFormat.getText();
	    }
	}
	
	public static ArrayList<String> get_records()
	{
		return records;
	}
	
	public static void set_input(String file_name)
	{
		try
		{
			input=new Scanner(Paths.get(file_name)); 
		}
		catch( IOException ioException)
		{
			System.err.println("Error openning file.Terminating");
			System.exit(1);
		}		
	}
}

