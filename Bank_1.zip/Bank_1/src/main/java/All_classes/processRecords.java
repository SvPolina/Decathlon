package All_classes;

import java.awt.List;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.EnumSet;
import java.util.Iterator;
import java.lang.Number ;

public class processRecords
{  
	private Map<String,Integer> name_score ;
	private final ArrayList<String> all_records;
	private Map<String,String> name_achievements;	
	private Map<Integer,Integer> score_freq;
	private Map<Integer,String > score_places;
	private Map<String,String> places_name;
	private Map<String,ArrayList<Double>> name_achievements_D;	
	private ArrayList<sportsman> sportsmen;
	private String out_name;
	private Double last_rec;


public processRecords(ArrayList<String> records,String out_name)
	{
		this.all_records=records;
		this.out_name=out_name;
	}
	
//Creates map of key-name(string),value-achievements Arraylist<Double>. 
private void create_records()
	{
		name_achievements_D=new HashMap<>();
		name_achievements=new HashMap<String,String>();	
		for (String r:all_records)
		{	
//Break input string into name and achievement.
			ArrayList<Double> L=new ArrayList<Double>();
			String[] tk=r.split(";");      
			String name=tk[0];
			String last=tk[tk.length-1];
			String achievement="";
//Create achievements string.
			for (int i=1; i<tk.length;i++)			
			{
				achievement+=" "+tk[i];
			}
//Create map of key-name(string) and value-achievement(string).
			name_achievements.put(name, achievement);			
		    			
			for (int i=1;i<tk.length-1;i++)
			{   
				Double t=Double.parseDouble(tk[i]);				
				L.add(t);
			}
			
			Double last_d=proc_last_rec(last);
			L.add(last_d);
//create map of key-name(string) and value-achievements Arraylist<Double>. 
			name_achievements_D.put(name,L);			
		}		
	}

//Converts last record into seconds.
public Double proc_last_rec(String last)
	{
		String[] evl=last.split("[/.,\';`]"); 		
		Double[] evl_d=new Double[3];
		
		for (int i=0;i<evl.length;i++)
		{   
			evl_d[i]=Double.parseDouble(evl[i]);					
		}		
		last_rec=evl_d[0]*60+evl_d[1]+evl_d[2]/100;
		return last_rec;
	}
	
//Calculate the total score of each athlete.	
private void countScore()
	{   
	  //Create map.key- name(String) , value-score(int).
		name_score=new HashMap<String,Integer>();		
		Set<String> list= name_achievements_D.keySet();
		ArrayList<String> a_list=new ArrayList<String>(list);
		int key_count=a_list.size();
		double a;
		double b;
		double c;
		int score=0;
		for (int i=0; i<key_count;i++)
		{
			ArrayList<Double> current=name_achievements_D.get(a_list.get(i));	
			
			for(int j=0; j<current.size();j++)
			{
				Event e=Event.values()[j];
				a=Double.parseDouble(e.getA());
				b=Double.parseDouble(e.getB());
				c=Double.parseDouble(e.getC());
				double performance=current.get(j);
				
				//Apply calculation formula to obtain the score in accordance with the event
				if(j==0||j==4||j==5||j==9)
				{
					score+=(int)Math.round( (a*Math.pow((b-performance),c)));
					double k=(performance-b);						
				}
				if(j==1||j==3||j==7)
				{  
					performance=100*performance;
					score+=(int)Math.round((a*Math.pow((performance-b),c)));
				}
				if(j==2||j==6||j==8)
				{
					score+=(int)Math.round((a*Math.pow((performance-b),c)));
				}	
				
			}			
			name_score.put(a_list.get(i), score);
			score=0;
		}	
		
	}

//Create map. Each Score(int)- frequency(int).
private void countFreq()
{ 
  Collection<Integer> unique_scores=name_score.values();
  score_freq=new HashMap<Integer,Integer>();
  Set<Integer> unique_scores_set=new HashSet<> (unique_scores);
  
  for(Integer in:unique_scores_set)
  {
	 int freq=Collections.frequency(unique_scores, in);
	 score_freq.put(in, freq);	 
  }
}
	
//Orders records. 	
private void order()
   {   
	
		places_name=new HashMap<String,String>();
		score_places=new HashMap<Integer,String>();
		ArrayList<Integer> scr=new ArrayList<Integer>();
		sportsmen=new  ArrayList<sportsman>();		
		for(Integer in:name_score.values())
			{
				scr.add(in);
			}
		
		Collections.sort(scr,Collections.reverseOrder());
		scr.toArray();
		Integer[] scr_r= scr.toArray(new Integer[scr.size()]);		
		
//Make ordered map of scores(int)-places(string)
		int place_a=0;
		int score_a;
		int prev_score_a=0;
		String prev_name_a="";
		int prev_freq=0;
		int freq_count=1;
		int cur_freq;
		String places_a=""; 
		for(int i=0;i<scr_r.length;i++)
		{   
			score_a=scr_r[i];	
			cur_freq=score_freq.get(score_a);	
		
			if(prev_score_a!=score_a)
			{	
				if(cur_freq!=1)
				{  
					for(int j=0;j<cur_freq;j++)
					{
						places_a+=","+Integer.toString(place_a+j+1);				
					}	
					score_places.put(score_a,places_a);							
					prev_score_a=score_a;
					place_a=place_a+cur_freq;
				}
				else
					{
					place_a++;
					score_places.put(score_a,Integer.toString(place_a));				
					prev_score_a=score_a;
					}
			}
			else
			{
					score_places.put(score_a,places_a);	
					prev_score_a=score_a;
					freq_count++;
					if(freq_count==cur_freq)
					{
						places_a="";
						freq_count=0;
					}
			}
		}	
//arrange array list of athletes
		int score_b=0;
		int prev_score_b=0;
		ArrayList<String> prev_name_b=new ArrayList<String>();
		
		for(int i=0;i<scr_r.length;i++)
		{   
			score_b=scr_r[i];			
			for(String name:name_score.keySet())
			{  				
				if((name_score.get(name).equals(score_b))&&(!prev_name_b.contains(name)))
				{  
					sportsman athlet=new sportsman(name,name_achievements.get(name),name_achievements_D.get(name),Integer.toString(score_b), score_places.get(score_b));
					places_name.put(score_places.get(score_b), name);      
					sportsmen.add(athlet);							
					prev_score_b=score_b;
					prev_name_b.add(name);
					break;
				}	
			}
		}
	}


//Getter methods
	public  Map<String,String> get_places_name()
	{		
	return this.places_name;
	}
	
	public  Map<String, ArrayList<Double>> get_name_achievements_D()
	{		
		return this.name_achievements_D;
	}
	
	public  Map<String,Integer> get_name_score()
	{		
		return this.name_score;
	}
	
	public  Double get_last_d()
	{		
		return this.last_rec;
	}
	
//Performs by order the required procedures on the
//input records:Creates record list, perform calculations to receive the score, 
//orders the record by place/score,
//creates XML document.	
public void perform() 
	{   
		create_records();
		countScore();
		countFreq();
		order();
		Output_XML out=new Output_XML(sportsmen,out_name);
		out.doc_build();			
	}
	
public void output()
	{
		for(sportsman sp:sportsmen)
		{  
			System.out.println(sp.toString());
		}
	}
	
}