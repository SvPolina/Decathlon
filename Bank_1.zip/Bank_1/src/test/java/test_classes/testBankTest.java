package test_classes;

import static org.junit.Assert.*;


import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import All_classes.testBank;

public class testBankTest 
{
	private Scanner input;	
	private String[] my_records_arr={"Siim Susi","Beata Kana"};
	
	private  ArrayList<String> records;
	
	@Before
	public  void setUp() 
	{	
		testBank test=new testBank();		
		test.set_input("test.txt");		
	}
	 
	@Test
	public void test_readRecords() 
	{ 
	    testBank.readRecords();
	    ArrayList<String> records=testBank.get_records();	
	   	String[] records_arr= records.toArray(new String[0]);	  
	    Assert.assertArrayEquals(my_records_arr, records_arr);	
	}

}

