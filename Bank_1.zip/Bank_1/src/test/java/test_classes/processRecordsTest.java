package test_classes;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


import All_classes.processRecords;

public class processRecordsTest 
{
	private  processRecords test_case;
	private   Double[] d;
	private   Double[] d1;
	private static  String[] places;	
	private static  Integer[] scores;	
	private   Double[][] Data ;
	private static  String[] names_1;
	
	
   @Before
	public  void setUp() 
	{		 
		 String tot="Polina;12.61;5.00;9.22;1.50;60.39;16.43;21.60;2.60;35.81;5.25.72 ";	
		 String tot_1="Anna;12.61;5.00;9.22;1.50;60.39;16.43;21.60;2.60;35.81;5.25.72 ";
		 
		 d=new Double[]{12.61,5.00,9.22,1.50,60.39,16.43,21.60,2.60,35.81,325.72};
		 d1=new Double[]{12.61,5.00,9.22,1.50,60.39,16.43,21.60,2.60,35.81,325.72};		 
		 places=new String[]{",1,2",",1,2"};	
		 scores=new Integer[]{4205,4205};
		 Data = new Double[][]{d, d1 };		 
		 names_1= new String[]{"Polina","Anna"};
		 
		 ArrayList<String> records = new ArrayList<String>();		 
		 records.add(tot);	
		 records.add(tot_1);	
		 String out_name="file.xml";
  		 test_case=new processRecords(records,out_name);
  		 test_case.perform();
	}
   
   		
    @Test
   public void test_process_last_record()	
	{ 
       Assert.assertEquals(d[9],test_case.proc_last_rec("5.25.72"));
	}
   
	@Test
   public void test_create_records()	
	{	 			 
		 		 
		 Map<String, ArrayList<Double>> map_n_a =test_case.get_name_achievements_D();		 
		 Set<String>  my_name    = map_n_a.keySet();		 
		 List<String> list_names = new ArrayList<String>(my_name);
		 String[]     names      = list_names.toArray(new String[0]);
		 
		 Assert.assertArrayEquals(names_1, names);		 
		 int i=0;		 
		 for(String s: map_n_a.keySet())
		 {
			 List<Double> list=map_n_a.get(s);	
			 Double[] l_d= list.toArray(new Double[0]);		 
			 Assert.assertArrayEquals(Data[i],l_d);
			 i++;
		 }	 
	}	
	
	@Test
   public void test_countScore()
	{
		 Map<String, Integer> map_n_s =test_case.get_name_score();
		
		 int i=0;
		 
		 for(String s: map_n_s.keySet())
		 {
			 Integer score=map_n_s.get(s);				 		
			 Assert.assertEquals(scores[i],score);
			 i++;
		 }	 		 
	}
	
	@Test 
   public void test_order()
	{
		 Map<String, String> map_n_s =test_case.get_places_name();		 
		 int i=0;		 
		 for(String s: map_n_s.keySet())
		 {							 		
			 Assert.assertEquals(places[i],s);
			 i++;
		 }	 			
	}
	
	
}
